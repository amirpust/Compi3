#!/bin/bash

for t in {1..60}
do ./run_tests.bash $t
done
