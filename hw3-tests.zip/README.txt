1. Put everything in the same directory as hw3 executable.
2. run dos2unix hw3-tests/* run.bash run_tests.bash
3. ./run.bash to run all tests, ./run_tests.bash TEST_NUM to run a specific test.